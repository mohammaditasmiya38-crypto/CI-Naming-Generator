sap.ui.define(["sap/ui/core/mvc/Controller"], function(Controller) {
  "use strict";
  return Controller.extend("ci.ui5.controller.Main", {
    onInit: function() {
      // placeholder - UI5 scaffold initialized
    }
  });
});
