SAP CI Naming Generator — Project

This repository contains a static UI for the "SAP CI Naming Generator".
The original UI is intentionally preserved (HTML, CSS, JS separated).

Quick start (Python)

1. From the project root run:

```bash
python -m http.server 8000
```

2. Open http://localhost:8000/ in your browser.

Alternative (npm)

1. Install a simple static server globally if you prefer:

```bash
npm install -g http-server
```

2. Start the server:

```bash
http-server -p 8000
```

Files

- `index.html` — main page (kept as provided)
- `css/style.css` — stylesheet
- `js/app.js` — application logic

Notes

- OpenUI5 is bootstrapped from CDN in `index.html` using `sap-ui-core.js` and a small initializer in `js/app.js` creates a JSONModel exposing the page data to UI5.
- I preserved the original DOM and behaviour; if you want a full `sap.m` rewrite I can convert the form controls to UI5 components.

If you want, I can also add a small `package.json` and an npm script to run the site locally (no code changes to the UI files).