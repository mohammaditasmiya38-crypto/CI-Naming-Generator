// App initializer and existing behavior kept intact
// This file will also initialize the UI5 Component (scaffold) without changing the visible UI.

(function(){
  // expose existing globals so the inline script in index.html can still work
  window.PARTY_OPTIONS = window.PARTY_OPTIONS || [];
  window.ADAPTER_OPTIONS = window.ADAPTER_OPTIONS || [];
  window.BU_OPTIONS = window.BU_OPTIONS || [];
  window.BU_PROCESSES = window.BU_PROCESSES || {};

  // UI5 bootstrap: instantiate the scaffold component into a hidden container
  function initUI5Component(){
    if (!window.sap || !sap.ui || !sap.ui.core || !sap.ui.core.UIComponent) return;
    try{
      // Create an invisible container DIV to place the UI5 app so it doesn't alter the static UI
      var container = document.getElementById('ui5-container');
      if (!container){
        container = document.createElement('div');
        container.id = 'ui5-container';
        container.style.position = 'absolute';
        container.style.left = '-9999px';
        container.style.width = '1px';
        container.style.height = '1px';
        document.body.appendChild(container);
      }

      // Create and place UI5 Component
      sap.ui.getCore().attachInit(function(){
        sap.ui.component({
          name: 'ci.ui5',
          manifest: true
        }).then(function(oComp){
          oComp.placeAt(container);
        }).catch(function(e){
          console.warn('UI5 component init failed', e);
        });
      });
    }catch(e){ console.warn('UI5 init error', e); }
  }

  if (window.sap && sap.ui && sap.ui.getCore) initUI5Component();
  else window.addEventListener('sap-ui-loaded', initUI5Component);

})();
